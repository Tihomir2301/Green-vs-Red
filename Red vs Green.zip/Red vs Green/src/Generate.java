public class Generate {
    public int width;
    public int height;
    public int[][] board;             // 2d array for the grid in the class
    public int [] cell;              // The main cell that receives its properties from the input
    public int greenGeneration = 0;      //

    public Generate(int height, int width) {     // Constructor
        this.height = height;
        this.width = width;
        this.board = new int[height][width];    // Initializing the board array with the set height and width

    }


    public int getState(int x, int y) {     // Method for not having an IndexOutofbounds exception
        if (x < 0 || x >= height) {
            return 0;
        }
        if (y < 0 || y >= width) {
            return 0;
        }
        return this.board[x][y];
    }

    public int countGreenNeighbours(int x, int y) {      // Counting green neighbours for each colour in the grid
        int count = 0;

        count += getState(x - 1, y - 1);
        count += getState(x, y - 1);
        count += getState(x + 1, y - 1);

        count += getState(x - 1, y);
        count += getState(x + 1, y);

        count += getState(x - 1, y + 1);
        count += getState(x, y + 1);
        count += getState(x + 1, y + 1);

        return count;
    }
    public void countGreenGenerations(){          // Counting every every time our main cell has a green colour in a generation
        this.greenGeneration += 1;

    }
    public int getGreenGenerations(){          // Returning the number of generations that our main cell has had a green colour
        return this.greenGeneration;
    }


    public void action() {
        int newBoard[][] = new int[height][width];     // initializing a new 2d array for the loop

        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                int greenNeighbours = countGreenNeighbours(i, j);      // counting all green neighbours for a cell
                if (getState(i, j) == 1) {
                    if (greenNeighbours == 0 || greenNeighbours == 1 || greenNeighbours == 4        // Following the rules
                            || greenNeighbours == 5 || greenNeighbours == 7 || greenNeighbours == 8) {
                        newBoard[i][j] = 0;

                    } else if (greenNeighbours == 2 || greenNeighbours == 3 || greenNeighbours == 6) {         // Following the rules
                        newBoard[i][j] = 1;
                        if(i == cell[0] && j == cell[1]){        // Check if our main cell is the same as the green one
                            countGreenGenerations();            // If true we count it as a generation with a green main cell
                        }


                    }


                } else if (getState(i, j) == 0) {                                  // Following the rules
                    if (greenNeighbours == 3 || greenNeighbours == 6) {
                        newBoard[i][j] = 1;
                        if(i == cell[0] && j == cell[1]){                 // Check if our main cell is the same as the green one
                            countGreenGenerations();                      // If true we count it as a generation with a green main cell
                        }

                    } else if (greenNeighbours == 0 || greenNeighbours == 1 || greenNeighbours == 2                 // Following the rules
                            || greenNeighbours == 4 || greenNeighbours == 5 || greenNeighbours == 7
                            || greenNeighbours == 8) {
                        newBoard[i][j] = 0;
                    }
                }

            }
        }
        this.board = newBoard;       // Assigning the the newBoard matrix to the global board
    }
    public void printBoard() {               // printing the board
        System.out.println("---");
        for (int i = 0; i < height; i++) {
            String line = "|";
            for (int j = 0; j < width; j++) {
                if (this.board[i][j] == 0) {
                    line += "0";
                } else {
                    line += "1";
                }
            }
            line += "|";
            System.out.println(line);
        }
        System.out.println("---\n");
    }
    public void setCell(int arr[]){
        this.cell = arr;
    }

}
