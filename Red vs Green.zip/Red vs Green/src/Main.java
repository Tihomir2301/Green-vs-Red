import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int y;           // Height
        int x;          // Width

        System.out.println("Enter height and width of the grid which are width <= height < 1000");
        y = input.nextInt();  // Input for height
        x = input.nextInt(); // Input for width
        if ((x > y || x >= 1000) || y >= 1000) {       // Check for wrong input
            throw new IllegalArgumentException("Wrong input");
        }

        System.out.println("Enter successively  1s or 0s int the grid");
        Generate grid = new Generate(y, x);   // Creating an instance of class Generate
        for (int i = 0; i < grid.height; i++) {     // 1s an 0s inputs for the board array in Class Generate
            for (int j = 0; j < grid.width; j++) {

                grid.board[i][j] = input.nextInt();
                if (grid.board[i][j] != 1 && grid.board[i][j] != 0) {
                    throw new IllegalArgumentException("Input should be only 1 or 0"); // Check for wrong input
                } else
                    continue;
            }
        }

        System.out.println("Enter position of a cell");
        int yCoordinates = input.nextInt();            // Cell input for height in our grid
        int xCoordinates = input.nextInt();           // Cell input for width in our grid


        int[] cell = new int[]{yCoordinates, xCoordinates};   // Creating a 1d array with the cell's coordinates
        grid.setCell(cell);                                  // Calling a method a passing the 1d cell array

        System.out.println("Enter N number of generations");
        int n = input.nextInt();                             // Input for Generation N
        int count = 0;                                      //  Variable that is considered as a counter for a passed generation

        while (count <= n) {
            grid.printBoard();                 // Printing the grid
            grid.action();                    // Changing colours by following the rules with action method
            count++;                         // Counting
        }
        System.out.println("After " + n + " generations, there will be "     // Printing the final result
                + grid.getGreenGenerations() + " green colours.");


    }
}
